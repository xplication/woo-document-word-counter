<?php

/**
 * @link       http://www.angelleye.com/
 * @since      1.0.0
 *
 * @package    Woocommerce_Price_Per_Word
 * @subpackage Woocommerce_Price_Per_Word/public/partials
 */
?>
